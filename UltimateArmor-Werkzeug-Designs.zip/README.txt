ULTIMATE ARMOR – Werkzeug-Texturen
====================================

Enthalten sind 20 PNG-Texturen (32x32 Pixel), 20 Item-Definitionen und
20 klassische Handheld-Modelle:

Rubin:   sword, pickaxe, axe, shovel, hoe
Smaragd: sword, pickaxe, axe, shovel, hoe
Saphir:  sword, pickaxe, axe, shovel, hoe
Goetter: sword, pickaxe, axe, shovel, hoe

Einbau:
1. ZIP öffnen.
2. Den Ordner "assets" in den Ordner deines bestehenden Resourcepacks kopieren.
3. Vorhandene Dateien bei Nachfrage NICHT blind überschreiben; diese Dateien
   ergänzen die neuen Werkzeug-IDs.
4. Resourcepack neu laden (F3+T) oder Minecraft neu starten.

Die Item-IDs stimmen mit den setItemModel-Aufrufen im Plugin überein:
rubin_sword, smaragd_pickaxe, saphir_axe usw.

Hinweis:
Diese ZIP ist ein Ergänzungspaket und ersetzt nicht dein bestehendes
Ultimate-Armor-Resourcepack. Die vorhandene pack.mcmeta bleibt erhalten.
